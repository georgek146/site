package im.xiaoyao.presto.ethereum;

import com.facebook.presto.spi.connector.ConnectorTransactionHandle;

public enum EthereumTransactionHandle implements ConnectorTransactionHandle {
    INSTANCE
}
